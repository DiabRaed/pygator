# my_package/__init__.py
__version__ = "1.0.3"
