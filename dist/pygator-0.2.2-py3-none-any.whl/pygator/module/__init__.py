# my_package/__init__.py
from .module import *